@echo off
setlocal
cd /d "%~dp0"
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter no esta instalado o no esta agregado al PATH.
  echo Instala Flutter y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)
if exist rosario_catolico_build (
  echo La carpeta rosario_catolico_build ya existe.
  echo Renombrala o eliminala si deseas crearla de nuevo.
  pause
  exit /b 1
)
flutter create --platforms=android,ios --org com.rosariocatolico rosario_catolico_build
if errorlevel 1 exit /b 1
xcopy "lib" "rosario_catolico_build\lib" /E /I /Y >nul
xcopy "assets" "rosario_catolico_build\assets" /E /I /Y >nul
copy /Y "pubspec.yaml" "rosario_catolico_build\pubspec.yaml" >nul
copy /Y "l10n.yaml" "rosario_catolico_build\l10n.yaml" >nul
cd rosario_catolico_build
flutter pub get
if errorlevel 1 (
  echo ERROR al descargar dependencias.
  pause
  exit /b 1
)
echo.
echo Proyecto preparado en: %CD%
echo Para probar: flutter run
echo Para crear APK debug: flutter build apk --debug
pause

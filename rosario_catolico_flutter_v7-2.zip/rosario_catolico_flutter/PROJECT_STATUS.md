# Estado del proyecto — Rosario Católico

**Versión:** 0.6 (código fuente Flutter)  
**Objetivo:** Android e iOS  
**Idioma de las meditaciones:** español, transcritas del PDF facilitado.

## Incluido
- Selección de los cuatro grupos de misterios y de cada uno de sus cinco misterios.
- 20 misterios individuales con diez meditaciones cada uno (200 meditaciones).
- Sesión de oración con Padre Nuestro, meditación + Ave María, Gloria y oración de Fátima.
- Guardado local del paso por misterio.
- Oraciones finales, letanías y plegarias del Padre Pío.
- Interfaz en seis idiomas; los textos de oración y meditaciones incluidos en esta versión siguen en español.
- Lectura por voz TTS del dispositivo. La selección masculina/femenina depende de las voces que tenga instaladas el teléfono.

## Corrección importante de v0.6
La pantalla de inicio permite elegir el misterio individual. Antes enviaba el nombre del grupo (por ejemplo, “Misterios Gozosos”) a la sesión, lo que impedía recuperar la meditación correcta. También se corrigió la transcripción de las diez meditaciones de la Presentación del Niño Jesús en el Templo, usando las páginas 6–7 del PDF.

## Preparar el proyecto en Windows
Ejecuta `PREPARAR_ANDROID.bat` en una computadora con Flutter instalado. El script crea la estructura Android/iOS oficial mediante `flutter create`, copia el código y los recursos, y ejecuta `flutter pub get`.

## Estado de compilación
Este entorno no dispone del SDK de Flutter ni de Android SDK, por lo que no se ha generado ni probado un APK. El archivo ZIP es código fuente; no es una aplicación instalable. Para compilar Android se necesita Flutter y Android Studio/Android SDK. Para compilar y firmar iOS se necesita macOS con Xcode.


## Compilación remota desde el celular (v0.7)
Se añadió `.github/workflows/android-apk.yml` para compilar un APK de depuración en GitHub Actions y subirlo como Artifact. También se añadió `GUIA_COMPILAR_DESDE_CELULAR.md`. Requiere que el usuario cree un repositorio GitHub y suba el proyecto; esta sesión no tiene acceso a una cuenta GitHub del usuario ni a un servicio de compilación autenticado, por lo que no se ha ejecutado la compilación ni existe aún un APK.

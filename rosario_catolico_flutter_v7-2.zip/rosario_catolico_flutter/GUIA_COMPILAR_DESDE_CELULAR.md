# Obtener el APK desde tu celular Android

Esta carpeta incluye un flujo de compilación en GitHub Actions. No requiere instalar Flutter en el teléfono, pero sí subir el proyecto a una cuenta/repositorio de GitHub.

## Pasos
1. Abre https://github.com en Chrome e inicia sesión o crea una cuenta.
2. Crea un repositorio nuevo llamado `rosario-catolico`. Puedes dejarlo privado.
3. En el repositorio, usa **Add file > Upload files** y sube el contenido de esta carpeta ZIP (extrae el ZIP primero en el teléfono; si GitHub móvil no permite subir carpetas completas, usa GitHub Desktop desde una PC o una app Git compatible).
4. Asegúrate de que el archivo `.github/workflows/android-apk.yml` también quede en el repositorio. GitHub puede ocultar carpetas que empiezan por punto en algunos selectores móviles.
5. Abre la pestaña **Actions**, selecciona **Construir APK Android** y pulsa **Run workflow** (si no se inicia automáticamente al subir a `main`).
6. Espera a que termine el trabajo. Si queda verde, abre la ejecución y descarga **rosario-catolico-apk-debug** en **Artifacts**.
7. Extrae el archivo descargado y toca `app-debug.apk` para instalarlo. Android puede pedir permiso para instalar desde esa fuente.

## Importante
- Este flujo produce un APK de depuración para pruebas, no un APK firmado para publicar en Google Play.
- El paso `flutter analyze` detendrá la compilación si encuentra errores. Si ocurre, comparte una captura o el registro del error para corregirlo.
- No compartas contraseñas ni tokens de GitHub.
- Para iPhone se necesita compilar y firmar con macOS y Xcode.

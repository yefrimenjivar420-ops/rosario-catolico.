import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'l10n/app_localizations.dart';
import 'prayer_session_page.dart';
import 'final_prayers_page.dart';

void main() => runApp(const RosarioApp());

class RosarioApp extends StatefulWidget {
  const RosarioApp({super.key});
  @override
  State<RosarioApp> createState() => _RosarioAppState();
}

class _RosarioAppState extends State<RosarioApp> {
  Locale _locale = const Locale('es');
  @override
  void initState() {
    super.initState();
    _loadLocale();
  }
  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString('locale') ?? 'es';
    if (mounted) setState(() => _locale = Locale(code));
  }
  Future<void> _setLocale(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale', code);
    setState(() => _locale = Locale(code));
  }
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    onGenerateTitle: (context) => AppLocalizations.of(context)!.appTitle,
    locale: _locale,
    supportedLocales: const [Locale('es'), Locale('en'), Locale('pt'), Locale('fr'), Locale('it'), Locale('de')],
    localizationsDelegates: const [
      AppLocalizations.delegate,
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF80613B), brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF8F4EC),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF8F4EC), elevation: 0),
      cardTheme: CardThemeData(color: const Color(0xFFFFFCF6), elevation: 1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
    ),
    home: HomePage(onLocaleChanged: _setLocale),
  );
}

class HomePage extends StatefulWidget {
  final Future<void> Function(String) onLocaleChanged;
  const HomePage({super.key, required this.onLocaleChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FlutterTts _tts = FlutterTts();
  String _voice = 'female';
  bool _speaking = false;
  String _selectedMystery = 'joyful';
  String? _selectedMysteryTitle = 'La Anunciación';
  final Map<String, List<String>> _mysteryTitles = {
    'joyful': [
      'La Anunciación',
      'La Visitación de María a su prima Santa Isabel',
      'El nacimiento de Jesús',
      'La Presentación del Niño Jesús en el Templo',
      'El Niño Jesús perdido y hallado en el Templo',
    ],
    'luminous': [
      'El Bautismo de Jesús en el Jordán',
      'La auto-revelación de Jesús en las bodas de Caná',
      'El anuncio del Reino de Dios, invitando a la conversión',
      'La Transfiguración de Jesús',
      'La Institución de la Eucaristía',
    ],
    'sorrowful': [
      'La agonía de Jesús en el huerto de los olivos',
      'Jesús es azotado en la columna',
      'La coronación de espinas',
      'Jesús lleva la cruz a cuestas',
      'La crucifixión de Jesús',
    ],
    'glorious': [
      'La Resurrección',
      'La Ascensión de Jesús',
      'La venida del Espíritu Santo',
      'La Asunción de María',
      'La coronación de María Santísima',
    ],
  };
  final Map<String, Map<String, String>> _mysteries = {
    'joyful': {'es':'Misterios Gozosos','en':'Joyful Mysteries','pt':'Mistérios Gozosos','fr':'Mystères joyeux','it':'Misteri gaudiosi','de':'Freudenreiche Geheimnisse'},
    'luminous': {'es':'Misterios Luminosos','en':'Luminous Mysteries','pt':'Mistérios Luminosos','fr':'Mystères lumineux','it':'Misteri luminosi','de':'Lichtreiche Geheimnisse'},
    'sorrowful': {'es':'Misterios Dolorosos','en':'Sorrowful Mysteries','pt':'Mistérios Dolorosos','fr':'Mystères douloureux','it':'Misteri dolorosi','de':'Schmerzhafte Geheimnisse'},
    'glorious': {'es':'Misterios Gloriosos','en':'Glorious Mysteries','pt':'Mistérios Gloriosos','fr':'Mystères glorieux','it':'Misteri gloriosi','de':'Glorreiche Geheimnisse'},
  };

  Future<void> _speak(String text, String lang) async {
    await _tts.stop();
    await _tts.setLanguage(lang);
    await _tts.setSpeechRate(0.42);
    // La voz concreta disponible depende de las voces instaladas en el dispositivo.
    final voices = await _tts.getVoices;
    if (voices is List && voices.isNotEmpty) {
      final candidates = voices.where((v) => (v['locale']?.toString() ?? '').startsWith(lang)).toList();
      if (candidates.isNotEmpty) {
        final chosen = candidates.firstWhere(
          (v) => _voice == 'female'
            ? (v['name']?.toString().toLowerCase().contains('female') ?? false)
            : (v['name']?.toString().toLowerCase().contains('male') ?? false),
          orElse: () => candidates.first,
        );
        await _tts.setVoice({'name': chosen['name'], 'locale': chosen['locale']});
      }
    }
    await _tts.speak(text);
    setState(() => _speaking = true);
  }

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() { if (mounted) setState(() => _speaking = false); });
    _tts.setErrorHandler((_) { if (mounted) setState(() => _speaking = false); });
  }
  @override
  void dispose() { _tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final lang = Localizations.localeOf(context).languageCode;
    final mystery = _mysteries[_selectedMystery]![lang] ?? _mysteries[_selectedMystery]!['es']!;
    return Scaffold(
      appBar: AppBar(
        title: Text(l.appTitle, style: const TextStyle(fontWeight: FontWeight.w700, letterSpacing: .3)),
        actions: [
          PopupMenuButton<String>(
            tooltip: l.language,
            icon: const Icon(Icons.language),
            onSelected: widget.onLocaleChanged,
            itemBuilder: (_) => const [
              PopupMenuItem(value:'es', child:Text('🇪🇸 Español')),
              PopupMenuItem(value:'en', child:Text('🇺🇸 English')),
              PopupMenuItem(value:'pt', child:Text('🇧🇷 Português')),
              PopupMenuItem(value:'fr', child:Text('🇫🇷 Français')),
              PopupMenuItem(value:'it', child:Text('🇮🇹 Italiano')),
              PopupMenuItem(value:'de', child:Text('🇩🇪 Deutsch')),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: const LinearGradient(colors:[Color(0xFF4B3526),Color(0xFF8B6B43)], begin:Alignment.topLeft, end:Alignment.bottomRight),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.auto_awesome, color: Color(0xFFE8D4A8), size: 30),
                const SizedBox(height:18),
                Text(l.welcome, style: const TextStyle(color:Color(0xFFF7EBD5),fontSize:26,fontWeight:FontWeight.bold)),
                const SizedBox(height:8),
                Text(l.tagline, style: const TextStyle(color:Color(0xFFE9DCC8),fontSize:15,height:1.4)),
                const SizedBox(height:20),
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor:const Color(0xFFF4E8D1),foregroundColor:const Color(0xFF4B3526)),
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PrayerSessionPage(mysteryTitle: _selectedMysteryTitle ?? _mysteryTitles[_selectedMystery]!.first))),
                  icon: const Icon(Icons.play_arrow),
                  label: Text(l.startPrayer),
                )
              ]),
            ),
            const SizedBox(height:24),
            Text(l.chooseMystery, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),
            const SizedBox(height:12),
            ..._mysteries.entries.map((e) => Card(
              child: RadioListTile<String>(
                value:e.key, groupValue:_selectedMystery,
                activeColor:const Color(0xFF80613B),
                title:Text(e.value[lang] ?? e.value['es']!,style:const TextStyle(fontWeight:FontWeight.w600)),
                subtitle:Text(_dayFor(e.key, lang)),
                onChanged:(v) => setState(() {
                  _selectedMystery = v!;
                  _selectedMysteryTitle = _mysteryTitles[v]!.first;
                }),
              ),
            )),
            const SizedBox(height:12),
            Text('Selecciona el misterio', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height:8),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: _mysteryTitles[_selectedMystery]!.contains(_selectedMysteryTitle)
                        ? _selectedMysteryTitle
                        : _mysteryTitles[_selectedMystery]!.first,
                    items: _mysteryTitles[_selectedMystery]!
                        .map((title) => DropdownMenuItem<String>(value: title, child: Text(title, overflow: TextOverflow.ellipsis)))
                        .toList(),
                    onChanged: (value) => setState(() => _selectedMysteryTitle = value),
                  ),
                ),
              ),
            ),
            const SizedBox(height:12),
            Card(child: ListTile(
              leading: const CircleAvatar(backgroundColor: Color(0xFFEDE2D0), child: Icon(Icons.menu_book, color: Color(0xFF80613B))),
              title: const Text('Oraciones finales y Padre Pío', style: TextStyle(fontWeight: FontWeight.w600)),
              subtitle: const Text('Letanías, oraciones y plegarias para escuchar o leer'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FinalPrayersPage())),
            )),
            const SizedBox(height:16),
            Card(child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
                Text(l.audioSettings,style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),
                const SizedBox(height:12),
                SegmentedButton<String>(
                  segments:[ButtonSegment(value:'female',label:Text(l.female),icon:const Icon(Icons.record_voice_over)),ButtonSegment(value:'male',label:Text(l.male),icon:const Icon(Icons.voice_chat))],
                  selected:{_voice}, onSelectionChanged:(s)=>setState(()=>_voice=s.first),
                ),
                const SizedBox(height:10),
                Text(l.voiceNote,style:Theme.of(context).textTheme.bodySmall),
                const SizedBox(height:14),
                Row(children:[
                  Expanded(child:Text(_selectedMysteryTitle ?? mystery,style:const TextStyle(fontWeight:FontWeight.w600))),
                  IconButton(onPressed:() async { if(_speaking){await _tts.stop();setState(()=>_speaking=false);} else {await _speak('${_selectedMysteryTitle ?? mystery}. ${l.welcomePrayer}',lang);} },icon:Icon(_speaking?Icons.stop_circle:Icons.play_circle_fill),iconSize:34,color:const Color(0xFF80613B)),
                ])
              ]),
            )),
            const SizedBox(height:20),
            Center(child:Text(l.footer,style:Theme.of(context).textTheme.bodySmall?.copyWith(color:Colors.brown))),
          ],
        ),
      ),
    );
  }

  String _dayFor(String key, String lang) {
    const es = {'joyful':'Lunes y sábado','luminous':'Jueves','sorrowful':'Martes y viernes','glorious':'Miércoles y domingo'};
    const en = {'joyful':'Monday and Saturday','luminous':'Thursday','sorrowful':'Tuesday and Friday','glorious':'Wednesday and Sunday'};
    return (lang=='en'?en:es)[key]!;
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class FinalPrayersPage extends StatefulWidget {
  const FinalPrayersPage({super.key});
  @override
  State<FinalPrayersPage> createState() => _FinalPrayersPageState();
}

class _FinalPrayersPageState extends State<FinalPrayersPage> {
  final FlutterTts _tts = FlutterTts();
  bool _speaking = false;
  final List<Map<String, String>> _prayers = const [
    {'title':'Padre Nuestro','text':'Padre nuestro, que estás en el Cielo, santificado sea tu Nombre; venga a nosotros tu Reino; hágase tu Voluntad, en la Tierra como en el Cielo. Danos hoy nuestro pan de cada día; perdona nuestras ofensas, como también nosotros perdonamos a los que nos ofenden; no nos dejes caer en la tentación, y líbranos del mal. Amén.'},
    {'title':'Ave María','text':'Dios te salve, María, llena eres de Gracia. El Señor es contigo. Bendita, Tú, eres, entre todas las mujeres, y bendito es el Fruto de tu vientre, Jesús. Santa María, Madre de Dios, ruega por nosotros, pecadores, ahora y en la hora de nuestra muerte. Amén.'},
    {'title':'Gloria','text':'Gloria al Padre, y al Hijo y al Espíritu Santo. Como era en el principio, ahora y siempre, y por los siglos de los siglos. Amén.'},
    {'title':'Oración de Fátima','text':'Oh, Jesús mío, perdona nuestros pecados, líbranos del fuego del Infierno y lleva al Cielo a todas las almas. Socorre especialmente a las más necesitadas de tu Divina Misericordia. Amén.'},
    {'title':'Salve','text':'Dios te Salve, Reina y Madre, Madre de la Misericordia, vida, dulzura y esperanza nuestra. Dios te Salve, a ti llamamos los desterrados hijos de Eva. A ti suspiramos gimiendo y llorando en este valle de lágrimas. Ea pues, Señora, abogada nuestra, vuelve a nosotros esos tus ojos misericordiosos, y después de este destierro muéstranos a Jesús, Fruto bendito de tu vientre. Oh Clemente, oh Piadosa, oh dulce Virgen María, ruega por nosotros Santa Madre de Dios, para que seamos dignos de alcanzar las Divinas Gracias y Promesas de nuestro Señor Jesucristo. Amén.'},
    {'title':'Letanías de la Santísima Virgen','text':'Señor, ten piedad. Cristo, ten piedad. Señor, ten piedad. Cristo, óyenos. Cristo, escúchanos. Dios Padre Celestial, ten piedad y misericordia de nosotros. Dios Hijo redentor del Mundo, ten piedad de nosotros. Dios Espíritu Santo, ten piedad de nosotros. Santísima Trinidad, que eres un solo Dios, ten piedad de nosotros. Santa María, ruega por nosotros. Santa Madre de Dios, ruega por nosotros. Santa Virgen de las Vírgenes, ruega por nosotros. Madre de Jesucristo, ruega por nosotros. Madre de la Iglesia, ruega por nosotros. Madre de la Divina Gracia, ruega por nosotros. Madre Purísima, ruega por nosotros. Madre castísima, ruega por nosotros. Madre intacta, ruega por nosotros. Madre incorrupta, ruega por nosotros. Madre inmaculada, ruega por nosotros. Madre amable, ruega por nosotros. Madre admirable, ruega por nosotros. Madre del buen consejo, ruega por nosotros. Madre del Creador, ruega por nosotros. Madre del Salvador, ruega por nosotros. Virgen prudentísima, ruega por nosotros. Virgen digna de reverencia, ruega por nosotros. Virgen digna de alabanza, ruega por nosotros. Virgen poderosa, ruega por nosotros. Virgen clemente, ruega por nosotros. Virgen fiel, ruega por nosotros. Espejo de justicia, ruega por nosotros. Trono de la sabiduría, ruega por nosotros. Causa de nuestra alegría, ruega por nosotros. Vaso espiritual, ruega por nosotros. Vaso honorable, ruega por nosotros. Vaso insigne de devoción, ruega por nosotros. Rosa mística, ruega por nosotros. Torre de David, ruega por nosotros. Torre de marfil, ruega por nosotros. Casa de Oro, ruega por nosotros. Arca de la alianza, ruega por nosotros. Puerta del Cielo, ruega por nosotros. Estrella de la mañana, ruega por nosotros. Salud de los enfermos, ruega por nosotros. Refugio de los pecadores, ruega por nosotros. Consoladora de los afligidos, ruega por nosotros. Auxilio de los cristianos, ruega por nosotros. Reina de los Ángeles, ruega por nosotros. Reina de los patriarcas, ruega por nosotros. Reina de los profetas, ruega por nosotros. Reina de los apóstoles, ruega por nosotros. Reina de los mártires, ruega por nosotros. Reina de los confesores, ruega por nosotros. Reina de las vírgenes, ruega por nosotros. Reina de todos los santos, ruega por nosotros. Reina concebida sin pecado original, ruega por nosotros. Reina elevada al Cielo, ruega por nosotros. Reina del Santísimo Rosario, ruega por nosotros. Reina de las Familias, ruega por nosotros. Reina de la Orden Capuchina, ruega por nosotros. Reina de la paz, ruega por nosotros. Cordero de Dios que quitas los pecados del mundo, perdónanos, Señor. Cordero de Dios que quitas los pecados del mundo, escúchanos, Señor. Cordero de Dios que quitas los pecados del mundo, ten piedad y misericordia de nosotros.'},
    {'title':'Bajo tu amparo','text':'Bajo tu amparo nos acogemos, santa Madre de Dios; no desprecies las súplicas que te dirigimos en nuestras necesidades; antes bien, líbranos de todos los peligros, oh Virgen gloriosa y bendita. Ruega por nosotros santa Madre de Dios. Para que seamos dignos de alcanzar las divinas gracias y promesas de nuestro Señor Jesucristo. Amén.'},
    {'title':'Oración final','text':'Te rogamos, oh Dios y Señor Nuestro, que concedas a nosotros, tus siervos, perpetua salud de alma y cuerpo y que por la gloriosa intercesión de la Bienaventurada siempre Virgen María, seamos libres de las tristezas de la vida presente y gocemos de las alegrías de la vida eterna, por Jesucristo, nuestro Señor. Amén.'},
    {'title':'Oración ante el Sagrario','text':'Señor Jesucristo, que por amor a los hombres permaneces noche y día en el Sacramento del Altar, esperando, llamando, acogiendo a los que vienen a visitarte. Yo creo que estás presente en el Sagrario. Te adoro, abismado en mi propia nada. Te agradezco por tantas gracias que me has concedido, en especial, por haberte entregado a mí. Por haberme dado como Madre a tu misma Madre y por haberme llamado a esta Iglesia. Amén.'},
    {'title':'Quédate, Señor, conmigo','text':'Has venido a visitarme como hermano y como amigo. Jesús no me dejes solo. ¡Quédate, Señor, conmigo! Por el mundo envuelto en sombras soy errante peregrino. Dame tu luz y tu gracia. ¡Quédate, Señor, conmigo! En este preciso instante abrazado estoy contigo. Que esta unión nunca me falte. ¡Quédate, Señor, conmigo! Acompáñame en la vida, tu presencia necesito. Sin ti desfallezco y caigo. ¡Quédate, Señor, conmigo! Declinando está la tarde, voy corriendo como un río al hondo mar de la muerte. ¡Quédate, Señor, conmigo! En la pena y en el gozo sé mi aliento mientras vivo, hasta que muera en tus brazos. ¡Quédate, Señor, conmigo!'},
    {'title':'Oración compuesta por el Padre Pío','text':'Oh, Jesús, destruye en mí todo lo que no sea de tu agrado y escribe tus dolores en mi corazón con el fuego de tu Caridad. Apriétame fuertemente junto a Ti, suave y eternamente, para que nunca te abandone en tus dolores. Que yo pueda reposar sobre tu Corazón, en los sufrimientos de la vida, para conseguir de este modo mi recuperación. Que mi espíritu no tenga otro deseo que vivir a tu lado, en el huerto y saciarme de las penas de tu Corazón, que mi alma se llene de tu Sangre y se alimente contigo con el pan de tus sufrimientos. Amén.'},
  ];

  Future<void> _read(String title, String text) async {
    await _tts.stop();
    await _tts.setLanguage('es');
    await _tts.setSpeechRate(0.42);
    await _tts.speak('$title. $text');
    if (mounted) setState(() => _speaking = true);
  }

  @override
  void initState() {
    super.initState();
    _tts.setCompletionHandler(() { if (mounted) setState(() => _speaking = false); });
    _tts.setErrorHandler((_) { if (mounted) setState(() => _speaking = false); });
  }
  @override
  void dispose() { _tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Oraciones finales y Padre Pío'), actions: [IconButton(tooltip:'Detener audio', onPressed:() async { await _tts.stop(); setState(()=>_speaking=false); }, icon:const Icon(Icons.stop_circle_outlined))]),
    body: ListView.builder(padding:const EdgeInsets.all(16), itemCount:_prayers.length, itemBuilder:(context,i) {
      final p=_prayers[i];
      return Card(margin:const EdgeInsets.only(bottom:12), child: ExpansionTile(
        leading:const Icon(Icons.volunteer_activism, color:Color(0xFF80613B)),
        title:Text(p['title']!, style:const TextStyle(fontWeight:FontWeight.w600)),
        children:[Padding(padding:const EdgeInsets.fromLTRB(18,0,18,18), child:Column(crossAxisAlignment:CrossAxisAlignment.stretch, children:[Text(p['text']!, style:const TextStyle(height:1.65)), const SizedBox(height:10), Align(alignment:Alignment.centerRight, child:TextButton.icon(onPressed:()=>_read(p['title']!,p['text']!), icon:const Icon(Icons.volume_up), label:const Text('Escuchar')))]))],
      ));
    }),
  );
}

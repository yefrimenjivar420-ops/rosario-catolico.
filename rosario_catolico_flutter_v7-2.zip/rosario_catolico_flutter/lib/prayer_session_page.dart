import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'mystery_meditations.dart';

class PrayerStep {
  final String title;
  final String text;
  const PrayerStep(this.title, this.text);
}

const ourFather = 'Padre nuestro, que estás en el cielo, santificado sea tu Nombre; venga a nosotros tu Reino; hágase tu voluntad en la tierra como en el cielo. Danos hoy nuestro pan de cada día; perdona nuestras ofensas, como también nosotros perdonamos a los que nos ofenden; no nos dejes caer en la tentación y líbranos del mal. Amén.';

const hailMary = 'Dios te salve, María, llena eres de gracia; el Señor es contigo. Bendita tú eres entre todas las mujeres y bendito es el fruto de tu vientre, Jesús. Santa María, Madre de Dios, ruega por nosotros, pecadores, ahora y en la hora de nuestra muerte. Amén.';

const gloryBe = 'Gloria al Padre, y al Hijo, y al Espíritu Santo. Como era en el principio, ahora y siempre, por los siglos de los siglos. Amén.';

const fatimaPrayer = 'Oh, Jesús mío, perdona nuestros pecados, líbranos del fuego del Infierno y lleva al Cielo a todas las almas. Socorre especialmente a las más necesitadas de tu Divina Misericordia. Amén.';

class PrayerSessionPage extends StatefulWidget {
  final String mysteryTitle;
  final String? meditation;
  const PrayerSessionPage({super.key, required this.mysteryTitle, this.meditation});
  @override
  State<PrayerSessionPage> createState() => _PrayerSessionPageState();
}

class _PrayerSessionPageState extends State<PrayerSessionPage> {
  final FlutterTts _tts = FlutterTts();
  int _step = 0;
  String _voice = 'female';
  bool _speaking = false;
  bool _progressLoaded = false;

  String get _progressKey => 'prayer_step_${widget.mysteryTitle}';

  @override
  void initState() {
    super.initState();
    _loadProgress();
    _tts.setCompletionHandler(() { if (mounted) setState(() => _speaking = false); });
    _tts.setErrorHandler((_) { if (mounted) setState(() => _speaking = false); });
  }

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getInt(_progressKey) ?? 0;
    if (mounted) setState(() { _step = saved.clamp(0, steps.length - 1).toInt(); _progressLoaded = true; });
  }

  Future<void> _saveProgress(int step) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_progressKey, step);
  }

  List<PrayerStep> get steps => [
    PrayerStep('Ofrecimiento', 'En el nombre del Padre, y del Hijo, y del Espíritu Santo. Amén. Vamos a contemplar: ${widget.mysteryTitle}.'),
    PrayerStep('Padre Nuestro', ourFather),
    ...List.generate(10, (i) => PrayerStep('Meditación ${i + 1} · Ave María', '${(mysteryMeditations[widget.mysteryTitle]?[i] ?? 'Contemplamos este misterio de la vida de Jesús y de María.')}\n\n$hailMary')),
    PrayerStep('Gloria', gloryBe),
    PrayerStep('Oración de Fátima', fatimaPrayer),
  ];

  Future<void> _speakCurrent() async {
    await _tts.stop();
    await _tts.setLanguage('es');
    await _tts.setSpeechRate(0.42);
    final voices = await _tts.getVoices;
    if (voices is List) {
      final spanish = voices.where((v) => (v['locale']?.toString() ?? '').startsWith('es')).toList();
      if (spanish.isNotEmpty) {
        final preferred = spanish.where((v) {
          final n = (v['name']?.toString() ?? '').toLowerCase();
          return _voice == 'female' ? n.contains('female') || n.contains('woman') : n.contains('male') || n.contains('man');
        }).toList();
        final selected = preferred.isNotEmpty ? preferred.first : spanish.first;
        await _tts.setVoice({'name': selected['name'], 'locale': selected['locale']});
      }
    }
    await _tts.speak('${steps[_step].title}. ${steps[_step].text}');
    setState(() => _speaking = true);
  }

  @override
  void dispose() { _tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final current = steps[_step];
    return Scaffold(
      appBar: AppBar(title: const Text('Rezar el Rosario')),
      body: SafeArea(child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(widget.mysteryTitle, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Paso ${_step + 1} de ${steps.length}', style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: (_step + 1) / steps.length, color: const Color(0xFF80613B), backgroundColor: const Color(0xFFE8DDCC)),
          const SizedBox(height: 24),
          Expanded(child: Center(child: SingleChildScrollView(child: Card(
            child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
              const Icon(Icons.volunteer_activism, size: 34, color: Color(0xFF80613B)),
              const SizedBox(height: 18),
              Text(current.title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              Text(current.text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.7)),
            ])),
          )))),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'female', label: Text('Femenina'), icon: Icon(Icons.record_voice_over)),
              ButtonSegment(value: 'male', label: Text('Masculina'), icon: Icon(Icons.voice_chat)),
            ],
            selected: {_voice}, onSelectionChanged: (s) => setState(() => _voice = s.first),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: _step > 0 ? () { _tts.stop(); setState(() { _step--; _speaking = false; }); _saveProgress(_step); } : null,
              icon: const Icon(Icons.chevron_left), label: const Text('Anterior'),
            )),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(
              onPressed: _speakCurrent,
              icon: Icon(_speaking ? Icons.volume_up : Icons.play_arrow),
              label: const Text('Escuchar'),
            )),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(
              onPressed: _step < steps.length - 1 ? () { _tts.stop(); setState(() { _step++; _speaking = false; }); _saveProgress(_step); } : null,
              icon: const Icon(Icons.chevron_right), label: const Text('Siguiente'),
            )),
          ]),
        ]),
      )),
    );
  }
}

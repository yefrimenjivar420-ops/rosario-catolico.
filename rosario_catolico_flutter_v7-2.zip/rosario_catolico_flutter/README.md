# Rosario Católico

Aplicación Flutter para rezar y meditar el Santo Rosario. Proyecto fuente orientado a Android e iOS.

## Funciones
- Cuatro grupos tradicionales de misterios y selección de cada misterio individual.
- 20 misterios y 200 meditaciones (10 por misterio), transcritas del PDF proporcionado.
- Sesión guiada con lectura en pantalla y voz TTS.
- Oraciones finales, letanías y plegarias atribuidas a San Pío incluidas en el documento fuente.
- Guardado local del paso alcanzado en cada misterio.
- Interfaz disponible en español, inglés, portugués, francés, italiano y alemán. En esta versión las oraciones y meditaciones se ofrecen en español.

## Crear el proyecto Android/iOS en Windows
1. Instala Flutter y Android Studio.
2. Extrae este ZIP.
3. Ejecuta `PREPARAR_ANDROID.bat`.
4. Abre la carpeta `rosario_catolico_build` con Android Studio o ejecuta `cd rosario_catolico_build` y luego `flutter run`.
5. Para generar APK de prueba: `flutter build apk --debug`. El APK se genera en `build/app/outputs/flutter-apk/app-debug.apk`.

El script no firma una versión de publicación. Para publicar en Google Play se necesita preparar la ficha, icono, políticas y firma de lanzamiento.

## iOS
El mismo proyecto puede generarse con Flutter, pero compilar y firmar para iPhone requiere macOS y Xcode.

## Audio
La lectura usa el motor TTS del dispositivo. La aplicación no incluye todavía grabaciones humanas ni archivos de audio descargables. La voz y la disponibilidad de voz masculina/femenina dependen del sistema instalado.

## Nota
Antes de publicar, revisar manualmente las transcripciones del PDF y probar la aplicación en dispositivos reales.
